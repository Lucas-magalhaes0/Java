package br.com.alura.java2.interfaces;

public class Teste {
	public static void main(String[] args) {
		
		AreaCalculavel a = new Retangulo(3, 2);
		System.out.println(a.calculaArea());
	}
}
