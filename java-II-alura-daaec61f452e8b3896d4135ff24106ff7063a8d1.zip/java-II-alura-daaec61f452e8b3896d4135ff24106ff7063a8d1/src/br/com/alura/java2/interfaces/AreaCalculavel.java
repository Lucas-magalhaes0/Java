package br.com.alura.java2.interfaces;

public interface AreaCalculavel {
	double calculaArea();
}
