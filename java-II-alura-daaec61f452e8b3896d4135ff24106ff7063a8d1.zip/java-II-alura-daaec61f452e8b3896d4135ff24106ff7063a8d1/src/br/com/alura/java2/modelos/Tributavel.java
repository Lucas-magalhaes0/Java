package br.com.alura.java2.modelos;

public interface Tributavel {
	double calculaTributos();
}
